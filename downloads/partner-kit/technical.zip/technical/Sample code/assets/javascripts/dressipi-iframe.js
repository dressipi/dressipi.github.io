(function() {
  var eventHandler;

  document.domain = "[retailer.com]";

  eventHandler = function(event) {
    var match;
    if (match = event.origin.match(/^https?:\/\/[\w-]+.[retailer.com]/)) {
      if (match = event.data.match(/^resize;(\d+)$/)) {
        return document.getElementById("dressipi-iframe").style.height = match[1] + "px";
      } else if (match = event.data.match(/^scroll;/)) {
        return window.scrollTo(0, 0);
      }
    }
  };

  if (typeof window.addEventListener !== "undefined") {
    window.addEventListener("message", eventHandler);
  } else {
    window.attachEvent("onmessage", eventHandler);
  }

}).call(this);
